/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package panzer.brainClass;

import java.awt.Rectangle;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Random;
import java.util.logging.Level;
import java.util.logging.Logger;
import javafx.animation.AnimationTimer;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.canvas.Canvas;
import javafx.scene.canvas.GraphicsContext;
import javafx.scene.control.Alert;
import javafx.scene.image.Image;
import javafx.scene.media.Media;
import javafx.scene.media.MediaPlayer;
import javafx.scene.paint.Color;
import javafx.scene.text.Font;
import javafx.scene.text.FontWeight;
import javafx.stage.Stage;
import panzer.entities.Bonus;
import panzer.entities.Brick;
import panzer.entities.Bullet;
import panzer.entities.Castle;
import panzer.entities.CoinsBonus;
import panzer.entities.EnemyCastle;
import panzer.entities.EnemyFreezeBonus;
import panzer.entities.PlayerTank;
import panzer.entities.Tank;
import panzer.entities.EnemyTank;
import panzer.entities.FastBulletBonus;
import panzer.entities.FullHealthBonus;
import panzer.entities.GameObject;
import panzer.entities.IceBullet;
import panzer.entities.Map;
import panzer.entities.MetalBullet;
import panzer.entities.PlayerCastle;
import panzer.entities.ProtectionBonus;
import panzer.entities.SpeedBonus;
import panzer.pkg2017.MainMenuController;
import panzer.pkg2017.Panzer2017;

/**
 *
 * @author Ndricim Rrapi
 */
public class GameEngine {

    int level;    
    static PlayerTank playerTank;
    private String username;
    public static boolean soundOnOrOff;
    ArrayList<EnemyTank> enemyTankList;   
    ArrayList<Bonus> bonusList;
    ArrayList<Castle> castleList;
    static ArrayList<Bullet> bulletList;
    static ArrayList<GameObject> allObjectsList ; 
    static ArrayList<Brick> bricksList;
    Map map;
    Image imageEnemyCastle, imagePlayerCastle;    
    int points;
    boolean drawBottomBar = true;
    static boolean exit = false;
    static Canvas canvas;    
    static FileManager fileManager;
    boolean win = false;
    public static ObjectDrawer timer;
    private final String ENEMY_COLLIDE_PLAYER = "sound/buzz_effect.mp3";
    private final String BULLET_COLLIDE_BRICK = "sound/destroy_brick.mp3";
    private final String BULLET_COLLIDE_ENEMY = "sound/enemy_shot.mp3";
    private final String BULLET_COLLIDE_PLAYER = "sound/player_shot.mp3";
    private final String GAME_LOST = "sound/game_lost.mp3";
    private final String SOUND_ON_IMG = "images/sound_on.png";
    private final String SOUND_OFF_IMG = "images/sound_off.png";  
   
   // Constructor   
    public GameEngine() throws IOException{      
        fileManager= new FileManager(); //makes sure file exists
        soundOnOrOff = fileManager.getSettings()[0] == 1; // 1 means sound is on, else sound will be false
        level = 1;
        exit = false;
        timer = new ObjectDrawer();
    }
    
    public void setUsername(String username) {
        this.username = username;
    }
    
    public static ArrayList<Bullet> getBulletList() {
        return bulletList;
    }
    
    // populate with objects
    public void initializeLevel1(boolean restartLevel){    
       
        allObjectsList = new ArrayList<>();
        try {        
            if(restartLevel){
                allObjectsList = new ArrayList<>();
                map = new Map(100,600,1);
            }
            else {
                map = new Map(100,600,level);
            }
             bricksList = map.getBricks();// keep track of bricks only
        } catch (IOException ex) {
            Logger.getLogger(GameEngine.class.getName()).log(Level.SEVERE, null, ex);
        }
        enemyTankList= createEnemyTankArrayList();
        bonusList = createBonusList();
        playerTank = new PlayerTank(true, 200, 200,38, 38,5);
      
        allObjectsList.add(playerTank);
        bulletList = new ArrayList<>();
        
        for (int i = 0; i < map.getBricks().size(); i++){
            allObjectsList.add(map.getBricks().get(i));
        }        
        setHealthBarEnemyCastle(new Image(Panzer2017.class.getResource("images/health_bar_king_enemy1.png").toExternalForm(),250,40,false,false));
        setHealthBarPlayerCastle(new Image(Panzer2017.class.getResource("images/health_bar_king1.png").toExternalForm(),250,40,false,false));
       
        castleList = createCastles();
        allObjectsList.add(castleList.get(0));
        allObjectsList.add(castleList.get(1));
        for (int i = 0; i < enemyTankList.size(); i++){
            allObjectsList.add(enemyTankList.get(i));
        }
        createBonusList();
        timer.start();
    }
    
    // creates both enemy-friendly castles
    public ArrayList<Castle> createCastles(){
        ArrayList<Castle> castle=new ArrayList<>();
        castle.add(new PlayerCastle(true, 0, 250,60, 60,60));
        castle.add(new EnemyCastle(true, 959, 250,60, 60,60));
        return castle;
    }
    
     // createas a list of bonuses
    private ArrayList<Bonus> createBonusList(){
        ArrayList<Bonus> temp = new ArrayList<>();
        temp.add(new EnemyFreezeBonus(true, 100,100,38,38 ));
        temp.add(new FastBulletBonus(true, 200,500,38,38 ));
        temp.add(new FullHealthBonus(true, 500,200,38,38 ));
        temp.add(new FullHealthBonus(true, 500,400,38,38 ));
        temp.add(new FullHealthBonus(true, 500,500,38,38 ));
        temp.add(new ProtectionBonus(true, 250,250,38,38 ));
        temp.add(new SpeedBonus(true, 200,250,38,38 ));
        temp.add(new FastBulletBonus(true, 200,250,38,38 ));
        temp.add(new FastBulletBonus(true, 250,250,38,38 ));
        temp.add(new EnemyFreezeBonus(true, 100,100,38,38 ));
        temp.add(new EnemyFreezeBonus(true, 550,250,38,38 ));
        temp.add(new EnemyFreezeBonus(true, 600,250,38,38 ));
        temp.add(new SpeedBonus(true, 200,250,38,38 ));
        temp.add(new FullHealthBonus(true, 500,500,38,38 ));        
        temp.add(new SpeedBonus(true, 500,350,38,38 ));
        temp.add(new EnemyFreezeBonus(true, 550,300,38,38 ));
        temp.add(new ProtectionBonus(true, 400,250,38,38 ));
        temp.add(new FastBulletBonus(true, 300,250,38,38 ));
        return temp;
    }
    
    // assigning initial location of enemy tanks
    private ArrayList<EnemyTank> createEnemyTankArrayList(){
        ArrayList<EnemyTank> enemies = new ArrayList<>();
        enemies.add(createSingleEnemyTank(40,40,1,1,1));//type 1 = normal tanks
     //   enemies.add(createSingleEnemyTank(800,350,1,3,2));//type 2 = fast tanks
        enemies.add(createSingleEnemyTank(850,400,5,1,3));//type 3 = life points = 5
        enemies.add(createSingleEnemyTank(800,150,1,1,2));//
        enemies.add(createSingleEnemyTank(300,350, 1,1,2));
        enemies.add(createSingleEnemyTank(850,450,1,1,2));
       return enemies;
    }
    
    private EnemyTank createSingleEnemyTank(float x, float y, int lifepoints , int speed_of_tank,int enemyType){
        EnemyTank temp = new EnemyTank(true, x, y,38, 38,lifepoints,speed_of_tank,enemyType);   
        return temp;
    }
    // returns all of the objects currently on the game
  
    public static ArrayList<GameObject> getAllObjectsList() {
        return allObjectsList;
    }
       
    public ArrayList<Bonus> getBonusList() {
        return bonusList;
    }
            
    public static PlayerTank getPlayerTank() {
        return playerTank;
    }
    
     // sets the image to the health bar of the enemy king
    public void setHealthBarEnemyCastle(Image img){
        imageEnemyCastle = img;
    }
    
     // sets the image to the health bar of the enemy king
    public void setHealthBarPlayerCastle(Image img){
        imagePlayerCastle = img;
    }
   
    public static void showPauseMenu() throws IOException {
        System.out.println(exit);
        if(exit==false){
            System.out.println("menu1");
            timer.start();}
        else{
        System.out.println("menu2");
        canvas.getScene().getWindow().hide();
        Parent root = FXMLLoader.load(Panzer2017.class.getResource("MainMenu.fxml"));
        Scene nnew=new Scene(root);                    
        Stage pause_stage=new Stage();
        pause_stage.setScene(nnew);
        pause_stage.show();}
    } 
     
    // The timer which runs the code on a certain framerate to offer smooth gameplay 
    public class ObjectDrawer extends AnimationTimer{
        Canvas thisCanvas;
        GraphicsContext gc ;
        int time;
        long oldNanoTime = System.nanoTime();  
        long oldNanoTime1 = System.nanoTime(); 
        long enemyNanoTime = 0;   
        long previosTime1 = 0;
        long previosTimeBonus = 0;
        
        
        @Override
        public void handle(long now) {
            //moveEnemy(0 ); moves enemy over the map 
            
            gc.clearRect(0, 0, 1000, 600);// clear field map
           
            gc.clearRect(390, 0, 104, 650); 
            gc.clearRect(555,600,100,300);
   
            drawAllObjectsOnScren(gc,points,time,drawBottomBar);
            
            previosTime1 += System.nanoTime() - oldNanoTime;
            oldNanoTime1 = System.nanoTime(); // update old nano time
            if( previosTime1 / 1000000.0 > 8 ){
                previosTime1 = 0;
                handleCollision(gc); 
                drawAllObjectsOnScren(gc,points,time,drawBottomBar);                         
            }
            
          //enemyTank.update(1);
            drawBottomBar = false;
            keepPlayerTankWithinBounds();
              for (int i = 0; i < enemyTankList.size();i++)
                  keepEnemyTankWithinBounds(enemyTankList.get(i));
            
            
            enemyNanoTime      += System.nanoTime() - oldNanoTime;
            previosTimeBonus += System.nanoTime() - oldNanoTime;
            oldNanoTime = System.nanoTime(); // update old nano time
            if(enemyNanoTime / 1000000.0 > 2000){ 
                for (int i = 0; i < enemyTankList.size();i++) {  
                    if(!playerOnSight(enemyTankList.get(i))){
                        ArrayList<Integer> temp =  returnProhibitedDirections(enemyTankList.get(i));
                        if(temp.size() == 3){
                            System.out.println("ROUTE");
                             findARoute(enemyTankList.get(i),temp);//  
                        }else if(temp.size() == 2){
                            System.out.println("ROUTE");
                             findARoute(enemyTankList.get(i),temp);//  
                        }
                        else {
                            System.out.println("ELSE");
                            enemyTankList.get(i).moveInDirection(getReverseDirection(enemyTankList.get(i).getDirection()), false);
                            ArrayList<Integer> temp2  = new ArrayList<>(1);
                            findARoute(enemyTankList.get(i), temp2);
                       }
                    }
                }
                enemyNanoTime = 0;
              
                //random enemy bullet shot 
                int random = getRandom();
                int eIndex = random/100; // tanks shoot here, what if they are null
                if(eIndex < enemyTankList.size()){
                    if(enemyTankList.get(eIndex) != null){
                        if(random >=0 && random <= 500)
                           enemyTankList.get(eIndex).shootMetalOrIce();
                        if(random >500 && random <= 1000)
                           enemyTankList.get(eIndex).shootMetalOrIce();
                        if(random >1000 && random <= 1500)
                           enemyTankList.get(eIndex).shootMetalOrIce();
                    }
                }
            }
            if(previosTimeBonus / 1000000.0 > 10000){ 
                  System.out.println("created bonus---------");   
                  if (bonusList.size()!=0){
                      allObjectsList.add( bonusList.get( bonusList.size()-1 ));
                  }
                  previosTimeBonus = 0;
              }          
                        
            setBulletMotion(getPlayerTank());
            
            for (int i = 0; i < enemyTankList.size();i++){
                setBulletMotion(enemyTankList.get(i));               
                shootIfOnSight( enemyTankList.get(i));
            }
            checkBonusExpired();
            checkEnemyFrozenDuration();
        }
        
        public void checkBonusExpired(){
            if(getPlayerTank().getMyBonusDuration() > 0){
                getPlayerTank().decrementMyBonusDuration();
                //System.out.println("decrementing");
                if(getPlayerTank().getMyBonusDuration()<=0){
                    if (getPlayerTank().getTank_speed() > 1)
                        getPlayerTank().setTank_speed(1);
                    if(getPlayerTank().hasShieldProtection()){
                        getPlayerTank().setShieldProtection(false);
                    }if(getPlayerTank().hasSuperBullet()){
                        getPlayerTank().setHasSuperBullet(false);
                    }if(getPlayerTank().hasIceBullet()){
                        getPlayerTank().setHasIceBullet(false);
                    }
                }
            }            
        }
        
        public void checkEnemyFrozenDuration(){
            if(getPlayerTank().getFrozenStateDuration()> 0){
                getPlayerTank().decrementFrozenStateDuration();
                if(getPlayerTank().getFrozenStateDuration() <=0){
                    getPlayerTank().setFrozenState(false);
                    getPlayerTank().setIconArrayList(getPlayerTank().getCurrentPlayerIcon());
                    getPlayerTank().setCustomImg(getPlayerTank().getCurrentPlayerIcon().get(getPlayerTank().getDirection()));
                }
            }
            for (int i = 0; i < enemyTankList.size();i++){
                if (enemyTankList.get(i).getFrozenStateDuration() > 0){
                    enemyTankList.get(i).decrementFrozenStateDuration();
                    if (enemyTankList.get(i).getFrozenStateDuration()<=0){
                        enemyTankList.get(i).setFrozenState(false);
                        enemyTankList.get(i).setCustomImg(enemyTankList.get(i).getEnemyImages().get(0));
                        enemyTankList.get(i).setIconArrayList(enemyTankList.get(i).getEnemyImages());
                        System.out.println("defrost ENEMY TANK " + i);
                    }
                }
            }
        }
                
        public void setBulletMotion(Tank enemyOrFriendly){
             if( enemyOrFriendly.getMyBullet() != null){
                decerementBulletRange();
                 if (enemyOrFriendly.getDirection() == 0){
                    if( enemyOrFriendly.getMyBullet() != null){
                         enemyOrFriendly.getMyBullet().setCoordinateY(enemyOrFriendly.getMyBullet().getCoordinateY()+enemyOrFriendly.getMyBullet().getSpeedY());
                    }
                 }else if (enemyOrFriendly.getDirection() == 1){
                    if( enemyOrFriendly.getMyBullet() != null){
                        enemyOrFriendly.getMyBullet().setCoordinateY(enemyOrFriendly.getMyBullet().getCoordinateY()+enemyOrFriendly.getMyBullet().getSpeedY());
                    }
                 }else if (enemyOrFriendly.getDirection() == 2){
                    if( enemyOrFriendly.getMyBullet() != null){
                        enemyOrFriendly.getMyBullet().setCoordinateX(enemyOrFriendly.getMyBullet().getCoordinateX()+enemyOrFriendly.getMyBullet().getSpeedX());
                    }
                 }else if (enemyOrFriendly.getDirection() == 3){
                    if( enemyOrFriendly.getMyBullet() != null){
                         enemyOrFriendly.getMyBullet().setCoordinateX(enemyOrFriendly.getMyBullet().getCoordinateX()+enemyOrFriendly.getMyBullet().getSpeedX());
                    }
                }
            }
        }
       
        public void drawAllObjectsOnScren(GraphicsContext g,int point,int time, boolean drawKings)  {
           for(int i = 0; i < getAllObjectsList().size() ; i++){
                GameObject o = getAllObjectsList().get(i);
			if(o.isAlive()){
                            //System.out.println("hi this is me");
                            g.drawImage(o.getImg(), (int)(o.getCoordinateX()) , (int)(o.getCoordinateY()));                       
                        }                        
                        // regulate bonus timing, fix the duration of the bonus on the map
                        if(o instanceof Bonus){                         
                            Bonus thisBonus = ((Bonus) o);
                            long duration = thisBonus.getDuration() ;
                            if(thisBonus.isBrute_destroy()){
                                deleteBonusFromMap(thisBonus);
                            }
                            else  if (duration > 0 ){    
                                thisBonus.setDuration(duration-1000);
                               // System.out.println(thisBonus.getDuration()+"decrementing duration==+?!!@#!@##!#!##@!#!#!#@!#!#!#");
                                if (thisBonus.getDuration() ==0 ){
                                     // System.out.println(duration+"duration CIMIIIIIII");
                                    deleteBonusFromMap(thisBonus);
                                        g.clearRect( 500, 605,40,40);
                                }
                            }
                        }
		}
            
           
            g.setFill(Color.WHITE);
            g.setFont(Font.font("Verdana", FontWeight.LIGHT, 25));
            g.fillText("Points :   " , 345, 635);
            g.fillText("Points : "+point , 345, 635);
            g.setStroke(Color.RED);
            g.setLineWidth(1);
            g.strokeLine(0, 601, 1000, 601);
            
            if(soundOnOrOff)
                g.drawImage(new Image(Panzer2017.class.getResource(SOUND_ON_IMG).toExternalForm(),30,30,false,false), 5, 5);     
            if(!soundOnOrOff)
                g.drawImage(new Image(Panzer2017.class.getResource(SOUND_OFF_IMG).toExternalForm(),30,30,false,false), 5, 5);
                
            
            
            if(getPlayerTank().getMyBonusDuration() > 0){
                if( getPlayerTank().getTank_speed() > 1 && drawKings ){ // he is moving fast
                    g.drawImage(new Image(Panzer2017.class.getResource("images/power_speed.png").toExternalForm(),40,40,false,false), 500, 605);
                }else if(getPlayerTank().hasShieldProtection() && drawKings){
                     g.drawImage(new Image(Panzer2017.class.getResource("images/power_shield.png").toExternalForm(),40,40,false,false), 500, 605);
            }
                
              g.setFill(Color.YELLOW);
              g.setFont(Font.font("Arial", FontWeight.BOLD, 25));
              g.fillText(getPlayerTank().getMyBonusDuration()/10000 +"", 555, 635);
            }
           if(drawKings){
            g.drawImage(new Image(Panzer2017.class.getResource("images/player_king.png").toExternalForm(),30,40,false,false), 15, 605);
            g.drawImage(new Image(Panzer2017.class.getResource("images/enemy_king.png").toExternalForm(),30,40,false,false), 955, 605);
           
            g.drawImage(imagePlayerCastle, 60, 605);
            g.drawImage(imageEnemyCastle, 690, 605);
           }
            canvas = g.getCanvas();
        }
        
        public void setGraphics(GraphicsContext c){
            gc = c;
        }      
        
        public void deleteBonusFromMap(Bonus bonus){
            bonus.setAlive(false);
            for(int m = 0; m < bonusList.size();m++){
                if ((bonusList.get(m).getDuration()<=0) || bonusList.get(m).isBrute_destroy() ) {
                    bonusList.remove(m);                                        
                }              
            }
        }
    }
    
    // method which stops player tank  to go beyond map bounds
    public void keepPlayerTankWithinBounds(){
         if(playerTank.getCoordinateY() <= 555 && playerTank.getCoordinateX() >= 0  && playerTank.getCoordinateY() >=0  && playerTank.getCoordinateX() <=958){
                 playerTank.update(1);// 1 = allows movement down
            }
            else if (playerTank.getCoordinateY()>=556 ) // 2 = limit movement beyond lower boundary y < 556
                playerTank.update(2);
            else if (playerTank.getCoordinateX() < 0 )
                playerTank.update(3);// 3 = limit movement beyond left boundary x > 0
            else if (playerTank.getCoordinateY() < 0){
                playerTank.update(4);// 4 = limit movement above upper boundary Y > 0
            }else if (playerTank.getCoordinateX() >958){
                playerTank.update(5);// 4 = limit movement beyond right boundary x <945
            }
    }
    
    //method which stops enemy tanks to go beyond map bounds
    public void keepEnemyTankWithinBounds(EnemyTank enemyTank){
        if(!enemyTank.getFrozenState()){
            if(enemyTank.getCoordinateY() <= 555 && enemyTank.getCoordinateX() >= 0  && enemyTank.getCoordinateY() >=0  && enemyTank.getCoordinateX() <=958){
                     enemyTank.update(1);// 1 = allows movement down
            }
            else if (enemyTank.getCoordinateY()>=556 ){ // 2 = limit movement beyond lower boundary y < 556
                enemyTank.update(2);
                 enemyTank.moveUp(false);
            }
            else if (enemyTank.getCoordinateX() < 0 ){
                enemyTank.update(3);// 3 = limit movement beyond left boundary x > 0
                 enemyTank.moveRight(false);
            }
            else if (enemyTank.getCoordinateY() < 0){
               //  changeRoute();
                enemyTank.update(4);// 4 = limit movement above upper boundary Y > 0
                enemyTank.moveDown(false);
            }else if (enemyTank.getCoordinateX() >958){
                enemyTank.update(5);// 4 = limit movement beyond right boundary x <945
                enemyTank.moveLeft(false);
            }
        }
    }
       
    // generate a random number
    public int getRandom(){
        Random rand = new Random();
        return rand.nextInt(1500) + 1;
    }
    
    // changes enemy tank's route when evoked - randomly decide a new path
    public void findARoute(EnemyTank enemyTank, ArrayList<Integer> pDir ){
        if(!enemyTank.getFrozenState()){
            if( pDir.size() == 0 ){ // keep on moving random
                    Random rand = new Random();
                    
                    int  n = rand.nextInt(1500) + 1;
                    if(n >= 0 && n <= 200){
                        switch (enemyTank.getDirection()) {
                            case 0:  enemyTank.moveDown(false);   break; //up
                            case 1:  enemyTank.moveUp(false);     break; //down
                            case 2:  enemyTank.moveRight(false);  break; //left
                            case 3:  enemyTank.moveLeft(false);   break; //right
                            default:  break;
                        }
                    }
                    else if(n > 200  && n <= 400){
                        switch (enemyTank.getDirection()) {
                            case 0:  enemyTank.moveLeft(false);  break; //left
                            case 1:  enemyTank.moveRight(false); break; //right
                            case 2:  enemyTank.moveDown(false);  break; //down
                            case 3:  enemyTank.moveDown(false);  break; //down
                            default: break;
                        }
                    }
                    else if (n > 400 && n <= 1500){
                        switch (enemyTank.getDirection()) {
                            case 0: enemyTank.moveLeft(false);  break; //left
                            case 1: enemyTank.moveRight(false); break; //right
                            case 2: enemyTank.moveDown(false);  break; //down
                            case 3: enemyTank.moveDown(false);  break; //down
                            default:break;
                        }
                    }
            
            }else if (pDir.size() > 0 ){ // find a new smart non-prohibitet path
                 System.out.println("jjj"+pDir.size());
                if(pDir.size() == 3){ //blocked
                  //  System.out.println("BLOCKED BY 3");
                    boolean allSidesWithBricks = true;
                    int directionWithBrick = -1;
                     System.out.println("SHOOOOOOOOOT");
                    for(int i = 0; i < pDir.size(); i++){
                        if(pDir.get(i) < 4){
                            allSidesWithBricks = false; // at least one side is an EnemyTank
                        }//else it's all surrounded by Bricks
                        else {
                            directionWithBrick = pDir.get(i); // keep at least one brick
                        }
                    }
                    if (allSidesWithBricks){ // just shoot somewhere
                        enemyTank.moveInDirection(pDir.get(0)-4, false); // move towards direction in index 0
                        enemyTank.shootMetalOrIce(); // shoot forward to clear the way
                        enemyTank.setSpeedX(0);
                        enemyTank.setSpeedY(0);
                       
                    }else{ // blocked but one enemy in one side
                        if(directionWithBrick == -1){ // surrounded with all enemies. wait until they're gone
                            enemyTank.moveInDirection(0, true); //stop the tank. No way out. or shoot forwards decide later
                        }else { // at least one brick so turn to brick and shoot and move
                            enemyTank.moveInDirection(directionWithBrick, false); // move towards direction in index 0
                            enemyTank.shootMetalOrIce(); // shoot forward to clear the way
                        }
                    }
                }else if (pDir.size() == 2){
                    int dontGo1 = pDir.get(0);
                    int dontGo2 = pDir.get(1);
                    int tankDir = enemyTank.getDirection();
                    int newDirection=0;
                    int sum = dontGo2+dontGo1+tankDir;
                    switch (sum) {
                        case 3:  newDirection = 3; break;
                        case 4:  newDirection = 2; break;
                        case 5:  newDirection = 1; break;
                        case 6:  newDirection = 0; break;
                        default: break;
                    }
                    enemyTank.moveInDirection(newDirection, false); // move towards newDirection
                }else if (pDir.size() == 1){
                    int dontGo1 = pDir.get(0);
                    if(dontGo1 >3) dontGo1 = dontGo1 - 4;
                    int tankDir = enemyTank.getDirection();
                    int sum = dontGo1+tankDir;
                    int newDirection = 0;
                    System.out.println("sum = "+ sum);
                    if(sum == 1) newDirection = 3; // 0 , 1
                    else if (sum == 2) newDirection = 1; // 0,2
                    else if (sum == 4) newDirection = 2; // 1,3
                    else if (sum == 5) newDirection = 0; // 2,3
                    else if (sum == 3 && (dontGo1 != 0 || tankDir != 0)) newDirection = 0; // 1,2
                    else newDirection = 1; // 0,3
                    System.out.println("new direction = " + newDirection);
                    enemyTank.moveInDirection(newDirection, false); // move towards newDirection
                }
            }
        }
    }
    
    //decided what happens when object collide
    public void handleCollision(GraphicsContext c){
        for(int i = 0 ; i < allObjectsList.size() ; i++){
            for(int j = 0 ; j < allObjectsList.size() ; j++){
                if(i == j) continue;
                
                if(i >= allObjectsList.size()) break;
                GameObject obj1 = allObjectsList.get(i);
                GameObject obj2 = allObjectsList.get(j);
                if(allObjectsList.get(i).collisionCheck(allObjectsList.get(j))){
                  
                    if(obj1 instanceof PlayerTank && obj2 instanceof Brick){
                        PlayerTank thatTank = (PlayerTank)obj1;
                        obj1.setSpeedX(0.0f);
                        obj1.setSpeedY(0.0f);
                        if (thatTank.getDirection() == 0)
                            obj1.setCoordinateY(thatTank.getCoordinateY() + 1);
                        else if (thatTank.getDirection() == 1 ){
                            obj1.setCoordinateY(thatTank.getCoordinateY() - 1);
                        }else if (thatTank.getDirection() == 2 ){
                            obj1.setCoordinateX(thatTank.getCoordinateX() + 1);
                        }else if (thatTank.getDirection() == 3 ){
                            obj1.setCoordinateX(thatTank.getCoordinateX()-1);
                        }
                    }  
                   // EnemyTank collidees with Brick: Enenmy Tank changes route
                   if(obj1 instanceof EnemyTank && obj2 instanceof Brick){
                       EnemyTank thisTank = (EnemyTank) obj1;
//                       
//                          System.out.println("x1__=" + obj1.getCoordinateX());
//                        System.out.println("y1__=" + obj1.getCoordinateY());
                       // System.out.println(obj1.getCoordinateX()-obj2.getCoordinateX());
                            ArrayList<Integer> temp = returnProhibitedDirections(obj1);
                        if(temp.size()==0){ 
                        if( obj1.getCoordinateX()-obj2.getCoordinateX() <=- 38){
                           obj1.setCoordinateX(obj1.getCoordinateX()-1);
                           //obj1.setSpeedX(0);
                           // ()obj1
                        }
                       else if( obj1.getCoordinateX()-obj2.getCoordinateX() >= 38){
                           obj1.setCoordinateX(obj1.getCoordinateX()+1);
                           // System.out.println("HEREEE");
                            //obj1.setSpeedX(0);
                        }
                       else if( obj1.getCoordinateY()-obj2.getCoordinateY() <= -38){
                           obj1.setCoordinateY(obj1.getCoordinateY()-1);
                            //obj1.setSpeedY(0);
                        }
                       else  if( obj1.getCoordinateY()-obj2.getCoordinateY() >=38){
                           obj1.setCoordinateY(obj1.getCoordinateY()+1);
                            //obj1.setSpeedY(0);
                        }
                            thisTank.moveInDirection(getReverseDirection(thisTank.getDirection()),false);
                        }
                         else  findARoute((EnemyTank)obj1,temp);
                        
                    }
                    if(obj1 instanceof EnemyTank && obj2 instanceof PlayerTank){   
                        if( obj1.getCoordinateX()-obj2.getCoordinateX() >= 38){
                            obj1.setCoordinateX(obj1.getCoordinateX()+5);
                            obj2.setCoordinateX(obj2.getCoordinateX()-5);
                        }                        
                         if( obj1.getCoordinateX()-obj2.getCoordinateX() <=-38){
                            obj1.setCoordinateX(obj1.getCoordinateX()-1);
                            obj2.setCoordinateX(obj2.getCoordinateX()+1);
                        }
                        if( obj1.getCoordinateY()-obj2.getCoordinateY() <=-38){
                           obj1.setCoordinateY(obj1.getCoordinateY()-1);
                            obj2.setCoordinateY(obj2.getCoordinateY()+1);
                        }
                        if( obj1.getCoordinateY()-obj2.getCoordinateY() >=38){
                            obj1.setCoordinateY(obj1.getCoordinateY()+1);
                            obj2.setCoordinateY(obj2.getCoordinateY()-1);
                        }
                        playSound(ENEMY_COLLIDE_PLAYER);
                        findARoute((EnemyTank)obj1,returnProhibitedDirections(obj1));
                    }
                    if(obj1 instanceof EnemyTank && obj2 instanceof EnemyTank){  
                        ArrayList<Integer> prohibitionObj1= returnProhibitedDirections(obj1);
                        ArrayList<Integer> prohibitionObj2= returnProhibitedDirections(obj2);
                        if(prohibitionObj1.size()==0 ){
                            if( obj1.getCoordinateX()-obj2.getCoordinateX() >= 38){
                               obj1.setCoordinateX(obj1.getCoordinateX()+1);
                                if(prohibitionObj2.size()==0 )
                                   obj2.setCoordinateX(obj2.getCoordinateX()-1);
                               // obj1.setSpeedX(0);
                                obj2.setSpeedX(0);
                             }                        
                            else  if( obj1.getCoordinateX()-obj2.getCoordinateX() <=-38){
                                obj1.setCoordinateX(obj1.getCoordinateX()-1);
                                if(prohibitionObj2.size()==0 )
                                obj2.setCoordinateX(obj2.getCoordinateX()+1);
                                //obj1.setSpeedX(0);
                                obj2.setSpeedX(0);
                            }
                            else if( obj1.getCoordinateY()-obj2.getCoordinateY() <=-38){
                               obj1.setCoordinateY(obj1.getCoordinateY()-1);
                                if(prohibitionObj2.size()==0 )
                               obj2.setCoordinateY(obj2.getCoordinateY()+1);
                                //obj1.setSpeedY(0);
                               obj2.setSpeedY(0);
                            }
                            else if( obj1.getCoordinateY()-obj2.getCoordinateY() >=38){
                                obj1.setCoordinateY(obj1.getCoordinateY()+1);
                                if(prohibitionObj2.size()==0 )
                                obj2.setCoordinateY(obj2.getCoordinateY()-1);
                                //obj1.setSpeedY(0);
                                obj2.setSpeedY(0);
                            }
                        
                            ((EnemyTank)obj1).moveInDirection(getReverseDirection(((EnemyTank)obj1).getDirection()), false);     
                         
                        } else{
                            findARoute((EnemyTank)obj1, prohibitionObj1);
                         //   findARoute((EnemyTank)obj2, prohibitionObj2); 
                        }
                       
                    }
                    if(obj1 instanceof Bullet && obj2 instanceof Brick){
                        Brick a=(Brick)obj2;
                        a.setLife(a.getLife()-1);
                         
                        if(a.getLife()==0){
                        System.out.println(a.getLife());
                        allObjectsList.remove(j);
                        obj2.setAlive(false);}
                        obj1.setAlive(false);
                        Bullet b = (Bullet)obj1;
                        b.setSpeedX(0);
                        b.setSpeedY(0);
                        playSound(BULLET_COLLIDE_BRICK);
                        if(b.getBulletOwner()== getPlayerTank())
                            points++;
                        
                        //remove the brick from the brick list
                        for(int m = 0; m < bricksList.size();m++){
                            if(!bricksList.get(m).isAlive()){
                                bricksList.remove(m);
                            }
                        }
                    }
                    if(obj1 instanceof Bullet && obj2 instanceof EnemyTank){                   
                         Bullet b = (Bullet)obj1;
                        if(b.getBulletOwner()==getPlayerTank()){
                            if(b instanceof IceBullet){
                                obj1.setAlive(false);
                                b.setSpeedX(0);
                                b.setSpeedY(0);
                                System.out.println("shotttt Enemy with ICEEE");                       
                                EnemyTank t = (EnemyTank)obj2;
                                t.setFrozenState(true);
                                t.incrementFrozenStateDuration();
                                t.setCustomImg(new Image(Panzer2017.class.getResource("images/enemy1_frozen.png").toExternalForm(),38,38,false,false));
                                playSound(BULLET_COLLIDE_ENEMY);
                            }else if (b instanceof MetalBullet){
                                obj1.setAlive(false);
                                b.setSpeedX(0);
                                b.setSpeedY(0);
                                System.out.println("shotttt Enemy");                       
                                EnemyTank t = (EnemyTank)obj2;
                                allObjectsList.remove(i);
                                if(t.getLife() >=1){                                    
                                    System.out.println("LIFE = "+ t.getLife());
                                    t.setLife(t.getLife()-1);// decrement life
                                  
                                    if (t.getLife() == 0){
                                        double posX = t.getCoordinateX();
                                        double posY = t.getCoordinateY();
                                        int enemyType= t.getEnemyType();
                                        t.setAlive(false);
                                        allObjectsList.get(j).setAlive(false);
                                        allObjectsList.remove(j);
                                        for(int m = 0; m<enemyTankList.size();m++){
                                            if(!enemyTankList.get(m).isAlive()){
                                                enemyTankList.remove(m);
                                            }
                                        }
                                        Bonus coin = new  CoinsBonus(true, posX, posY, 38, 38, enemyType);                                        
                                        allObjectsList.add(coin);
                                        
                                    }
                                }
                                playSound(BULLET_COLLIDE_ENEMY);
                                points+=50;
                            }
                        }
                    }
                     if(obj1 instanceof Bullet && obj2 instanceof PlayerTank){                   
                        Bullet b = (Bullet)obj1;
                        if (b.getBulletOwner()!=getPlayerTank()){
                            if(obj1 instanceof IceBullet){
                                obj1.setAlive(false);
                                b.setSpeedX(0);
                                b.setSpeedY(0);
                                System.out.println("shotttt by ICEEE ENEMY");                       
                              
                                getPlayerTank().setFrozenState(true);
                                getPlayerTank().incrementFrozenStateDuration();
                                getPlayerTank().setCustomImg(new Image(Panzer2017.class.getResource("images/enemy1_frozen.png").toExternalForm(),38,38,false,false));
                            }else{
                                if(!getPlayerTank().hasShieldProtection()){
                                    obj1.setAlive(false);
                                    b.setSpeedX(0);
                                    b.setSpeedY(0);
                                    allObjectsList.remove(i);
                                    System.out.println("shotttt Enemy");                       
                                    PlayerTank t = (PlayerTank)obj2;
                                    t.setLife(t.getLife()-1);
                                    System.err.println("Shot by enemy");
                                    if(t.getLife()==4){
                                        t.setIcon(t.get4LifeIconImages());
                                        t.setCustomImg(t.get4LifeIconImages().get(t.getDirection()));
                                        playSound(BULLET_COLLIDE_PLAYER);
                                    } 
                                    if(t.getLife()==3){
                                        t.setIcon(t.get3LifeIconImages());
                                        t.setCustomImg(t.get3LifeIconImages().get(t.getDirection()));
                                        playSound(BULLET_COLLIDE_PLAYER);
                                    }                          
                                    if(t.getLife()==2){
                                        t.setIcon(t.get2LifeIconImages());
                                        t.setCustomImg(t.get2LifeIconImages().get(t.getDirection()));
                                        playSound(BULLET_COLLIDE_PLAYER);
                                    }if(t.getLife()==1){
                                        t.setIcon(t.get1LifeIconImages());
                                        t.setCustomImg(t.get1LifeIconImages().get(t.getDirection()));
                                        playSound(BULLET_COLLIDE_PLAYER);
                                    } 
                                    if(t.getLife()==0){
                                        allObjectsList.remove(j);
                                        t.setAlive(false);
                                        System.err.println("Shot by enemy and DIED!!");
                                        playSound(GAME_LOST);
                                        timer.stop();
                                        System.out.println("----------->"+ false);
                                        showDialog( false, level);      
                                    } 
                                }
                            }
                        }                        
                    }
                     if(obj1 instanceof Bullet && obj2 instanceof EnemyCastle){
                        if (obj1.isAlive()){
                            if(((Bullet)obj1).getBulletOwner()==getPlayerTank()){
                                EnemyCastle temp = (EnemyCastle)obj2;
                                temp.setLife(temp.getLife()-10);
                                obj1.setAlive(false);
                                Bullet b = (Bullet)obj1;
                                b.setSpeedX(0);
                                b.setSpeedY(0);
                                drawBottomBar = true;
                                points += 40;
                                if (temp.getLife() == 50)
                                    setHealthBarEnemyCastle(new Image(Panzer2017.class.getResource("images/health_bar_king_enemy2.png").toExternalForm(),250,40,false,false));
                                else if (temp.getLife() == 40)
                                    setHealthBarEnemyCastle(new Image(Panzer2017.class.getResource("images/health_bar_king_enemy3.png").toExternalForm(),250,40,false,false));
                                else if (temp.getLife() == 30)
                                     setHealthBarEnemyCastle(new Image(Panzer2017.class.getResource("images/health_bar_king_enemy4.png").toExternalForm(),250,40,false,false));
                                else if (temp.getLife() == 20)
                                    setHealthBarEnemyCastle(new Image(Panzer2017.class.getResource("images/health_bar_king_enemy5.png").toExternalForm(),250,40,false,false));
                                else if (temp.getLife() == 10)
                                    setHealthBarEnemyCastle(new Image(Panzer2017.class.getResource("images/health_bar_king_enemy6.png").toExternalForm(),250,40,false,false));
                                else if (temp.getLife() == 0){
                                    setHealthBarEnemyCastle(new Image(Panzer2017.class.getResource("images/health_bar_king_enemy_empty.png").toExternalForm(),250,40,false,false));
                                    temp.setAlive(false);
                                    allObjectsList.remove(j);
                                    c.clearRect(0, 0, 1000, 600);
                                    timer.stop();
                                    win=true;
                                    level++;
                                    showDialog( win, level ); 
                                }                            
                            }
                        }
                    }if(obj1 instanceof Bullet && obj2 instanceof PlayerCastle){
                        if (obj1.isAlive()){
                            Bullet temp = (Bullet) obj1;
                                PlayerCastle temp2 = ((PlayerCastle)obj2);
                                System.out.println("======"+temp2.getLife());
                                temp2.setLife(temp2.getLife()-10);
                                obj1.setAlive(false);
                                Bullet b = (Bullet)obj1;
                                b.setSpeedX(0);
                                b.setSpeedY(0);
                                drawBottomBar = true; //let the canvas be redrawn
                                if (temp2.getLife() == 50)
                                    setHealthBarPlayerCastle(new Image(Panzer2017.class.getResource("images/health_bar_king2.png").toExternalForm(),250,40,false,false));
                                else if (temp2.getLife() == 40)
                                    setHealthBarPlayerCastle(new Image(Panzer2017.class.getResource("images/health_bar_king3.png").toExternalForm(),250,40,false,false));
                                else if (temp2.getLife() == 30)
                                    setHealthBarPlayerCastle(new Image(Panzer2017.class.getResource("images/health_bar_king4.png").toExternalForm(),250,40,false,false));
                                else if (temp2.getLife() == 20)
                                    setHealthBarPlayerCastle(new Image(Panzer2017.class.getResource("images/health_bar_king5.png").toExternalForm(),250,40,false,false));
                                else if (temp2.getLife() == 10)
                                    setHealthBarPlayerCastle(new Image(Panzer2017.class.getResource("images/health_bar_king6.png").toExternalForm(),250,40,false,false));
                                else if (temp2.getLife() == 0){
                                    setHealthBarPlayerCastle(new Image(Panzer2017.class.getResource("images/health_bar_king_empty.png").toExternalForm(),250,40,false,false));
                                    temp2.setAlive(false);
                                    allObjectsList.remove(j);
                                    c.clearRect(0, 0, 1000, 600);                                   
                                    timer.stop();
                                    showDialog( false, level  );                                    
                                }  
                            //}
                        }
                    }if(obj1 instanceof Bonus && obj2 instanceof PlayerTank){
                        if(obj1.isAlive()){
                            Bonus thisBonus = ((Bonus) obj1);
                            if(thisBonus instanceof SpeedBonus){ // finished
                                thisBonus.setDuration(-1);
                                getPlayerTank().setTank_speed(3);
                                getPlayerTank().incrementMyBonusDuration();
                                thisBonus.setBrute_destroy(true);
                                drawBottomBar = true; // draw it once
                            }else if(thisBonus instanceof ProtectionBonus){ // finished
                                thisBonus.setDuration(-1);
                                thisBonus.setBrute_destroy(true);
                                getPlayerTank().setShieldProtection(true);
                                System.out.println("shield set to = "+ getPlayerTank().hasShieldProtection());
                                getPlayerTank().incrementMyBonusDuration();
                                drawBottomBar = true; // draw it once
                            }else if(thisBonus instanceof EnemyFreezeBonus){
                                thisBonus.setDuration(-1);
                                getPlayerTank().incrementMyBonusDuration();
                                thisBonus.setBrute_destroy(true);
                                getPlayerTank().setHasIceBullet(true);
                            }else if(thisBonus instanceof FullHealthBonus){ // finished
                                thisBonus.setDuration(-1);                                
                                thisBonus.setBrute_destroy(true);
                                getPlayerTank().setLife(5);
                                castleList.get(0).setLife(60);
                                setHealthBarPlayerCastle(new Image(Panzer2017.class.getResource("images/health_bar_king1.png").toExternalForm(),250,40,false,false));
                                getPlayerTank().setIconArrayList(getPlayerTank().get5LifeIconImages());
                                drawBottomBar= true;
                            }else if (thisBonus instanceof FastBulletBonus){//finished
                                thisBonus.setDuration(-1);
                                getPlayerTank().incrementMyBonusDuration();
                                thisBonus.setBrute_destroy(true);
                                getPlayerTank().setHasSuperBullet(true);                                
                            }else if (thisBonus instanceof  CoinsBonus){
                                thisBonus.setDuration(-1);
                                thisBonus.setBrute_destroy(true);
                                points += ((CoinsBonus) thisBonus).getBonusPoints();
                            }                            
                        }                    
                    }
                }
            }
        }
    }
    
    // Return the prohibited directions towards which
    // When player collides, he stops and calls findARoute(). Yet, since that 
    // method generates random movement, the next movement might send our 
    // EnemyTank to merge it's position with some adjacent object. 
    // In such a case it would appear as a constant collision and the objects 
    // would glitch. To prevent that, when we collide, we look in other directions
    // and check if we can move there or not. This method will give in which 
    // directions we can not move. Knowing that we can call findARoute and 
    // set the new direction manually.
    public ArrayList<Integer> returnProhibitedDirections(GameObject tankObject){
        ArrayList<Integer> temp = new ArrayList<>();
        EnemyTank enemy = (EnemyTank)tankObject;
        for (int i = 0; i < bricksList.size(); i++){
            Rectangle brick = new Rectangle((int)(bricksList.get(i).getCoordinateX()) , (int)(bricksList.get(i).getCoordinateY()) , 40 , 40);
            Rectangle tank = new Rectangle((int)(enemy.getCoordinateX()-1) , (int)(enemy.getCoordinateY()-1), enemy.getWidth()+4, enemy.getHeight()+4);
            if(brick.intersects(tank)){
                int temporary = collisionPredicate(((EnemyTank)tankObject),bricksList.get(i));
                if( temporary != -1 ){
                    temp.add(temporary); // saving prohibited positions
                }
            }
        }
        for (int i = 0; i < enemyTankList.size(); i++){
            Rectangle enemy2 = new Rectangle((int)(enemyTankList.get(i).getCoordinateX()) , (int)(enemyTankList.get(i).getCoordinateY()) , 40 , 40);
            Rectangle tank = new Rectangle((int)(enemy.getCoordinateX()-1) , (int)(enemy.getCoordinateY()-1), enemy.getWidth()+4, enemy.getHeight()+4);
          
            int temporary = collisionPredicate(((EnemyTank)tankObject),enemyTankList.get(i));
            if( temporary != -1 ){
                System.out.println("heehe");
                temp.add(temporary); // saving prohibited positions
            }
        }
        System.out.println("Sizeee = " + temp.size());
        return temp;
    }
    
    public int getReverseDirection(int currDirection){
        if(currDirection ==0) return 1;
        else if (currDirection ==1) return 0;
        else if (currDirection == 2) return 3;
        else return 2;
    }
    
    /**
     * This method predicts whether the enemy is heading towards a closed area
     * Since EnemyTank's usually decide a new random direction/position when hitting
     * another object they might end up merging with the object(EnemyTank or Brick)
     * which could by coincidence be exactly at the place of the new random 
     * position. <br>This would cause a major glitch in the enemy behavior.In order 
     * to avoid that this method makes a lookahead predicate and tells warns the
     * GameEngine that this EnemyTank cannot move towards a random new position.
     * Instead, this method will generate a new correct direction for this tank to move
     * 
     * @param enemyTank : The current referred EnemyTank
     * @param adjacentObject : Could be a Brick or an EnemyTank
     * 
     * @return 
     * case : {0 = up, 1 = down, 2 = left, 3 = right} If one of these 
     * are returned they define that EnemyTank has gone to a dead end and needs to 
     * move in this new direction in order to get out of there<br>
     * 
     * case : {-1} : In this case, EnemyTank has a clear path on 4 sides, so the nor-
     * mal random function can be applied<br>
     * 
     * case : {4 = up,5 = down,6=left,7=right}: In this case the EnemyTank might
     * be surrounded by 1 or more objects. Thus the tank should shoot and then
     * move to get out of that difficult position. 
     * The return being > 3 signifies just that. <br>Furthermore, subtracting 4 from
     * any of the returned values will give the direction in which the Tank
     * needs to move after it has shot the brick<br>
     * 
     */
    public int collisionPredicate(EnemyTank enemyTank,GameObject adjacentObject){ // CAN CONSIDER TO ADD DEFAULT OBJECTS TRY LATER
        // initialize variables to keep the position of the tanks 
    
        double thisPosX = enemyTank.getCoordinateX();
        double thisPosY = enemyTank.getCoordinateY();
        double paramX   = adjacentObject.getCoordinateX() ;
        double paramY   = adjacentObject.getCoordinateY() ;
        double xDiff = thisPosX - paramX;
        double yDiff = thisPosY - paramY;
        boolean sth_On_TheRight = xDiff >= -40.0 && xDiff <= -38;
        boolean sth_On_TheLeft  = xDiff <= 42.0 && xDiff >= 40.0;
        boolean sth_On_TheBottom= yDiff >= -40 && yDiff <= -38;
        boolean sth_On_TheTop   = yDiff <= 42 && yDiff >= 40;
        
         //scenario 1:  I collided with something upwards, so check right, left, down 
        if(enemyTank.getDirection() == 0){ 
            System.out.println("diff="+xDiff + " ,YdIFF="+yDiff);
           if(sth_On_TheRight){ // checks if I have something on my right
                if (adjacentObject instanceof Brick){ // can be a brick
                   //  System.out.println("S1_1111");
                    return 7; // = right+ can shoot right, 7-4 = 3
                }else if (adjacentObject instanceof  EnemyTank){ // can be another fellow enemy tank
                    return 3; // = right  (can't shoot)
                } //38  , 37
            }else if (sth_On_TheLeft){ // checks if I have brick on my left
                if (adjacentObject instanceof  Brick){ // can be another fellow enemy tank
                    // System.out.println("S1");
                        return 6; // move left only
                } else if (adjacentObject instanceof  EnemyTank){ // can be another fellow enemy tank
                    return 2; // move left only
                }               
            }else if (sth_On_TheBottom){ // checks if I have something down
                if (adjacentObject instanceof Brick){ // can be a brick
                        return 5; // shoot down, move down
                }else if (adjacentObject instanceof  EnemyTank){ // can be another fellow enemy tank
                    return 1; // move down only
                }
            }
        }
         
        //scenario 2: I collided with something downwards, so check right, left, up 
        else if(enemyTank.getDirection() == 1){
            if(sth_On_TheRight){ // checks if I have something on my right
                if (adjacentObject instanceof Brick){ // can be a brick
                    return 7; // = right+ can shoot right, 7-4 = 3
                }else if (adjacentObject instanceof  EnemyTank){ // can be another fellow enemy tank
                    return 3; // = right  (can't shoot)
                }
            }else if (sth_On_TheLeft){ // checks if I have brick on my left
                if (adjacentObject instanceof  Brick){ // can be another fellow enemy tank
                    System.out.println("S2");
                        return 6; // move left only
                }else if (adjacentObject instanceof  EnemyTank){ // can be another fellow enemy tank
                    return 2; // move left only
                }               
            }else if (sth_On_TheTop){ // checks if I have brick up
                if (adjacentObject instanceof  Brick){ // can be another fellow enemy tank
                        return 4; // move left only
                }else if (adjacentObject instanceof  EnemyTank){ // can be another fellow enemy tank
                    return 0; // move left only
                } 
            }
        }
        
        //scenario 3: I collided with something leftwards, so check right, down, up 
        else if(enemyTank.getDirection() == 2){ //LEFT
            if (sth_On_TheTop){ // checks if I have brick up
                if (adjacentObject instanceof  Brick){ // can be another fellow enemy tank
                    return 4; // move or shoot
                }else if (adjacentObject instanceof  EnemyTank){ // can be another fellow enemy tank
                    return 0; // move  only
                }             
            }else if (sth_On_TheBottom){ // checks if I have something down
                if (adjacentObject instanceof Brick){ // can be a brick
                    return 5; // shoot down, move down
                }else if (adjacentObject instanceof  EnemyTank){ // can be another fellow enemy tank
                    return 1; // move down only
                }
            }else if(sth_On_TheRight){ // checks if I have something on my right
                if (adjacentObject instanceof Brick){ // can be a brick
                    return 7; // = right+ can shoot right, 7-4 = 3
                }else if (adjacentObject instanceof  EnemyTank){ // can be another fellow enemy tank
                    return 3; // = right  (can't shoot)
                }
            }
        }
        //scenario 4: I collided with something rightwards, so check down, left, up 
        else if(enemyTank.getDirection() == 3){
            if (sth_On_TheBottom){ // checks if I have something down
                if (adjacentObject instanceof Brick){ // can be a brick
                    return 5; // shoot down, move down
                }else if (adjacentObject instanceof  EnemyTank){ // can be another fellow enemy tank
                    return 1; // move down only
                }
            }if (sth_On_TheTop){ // checks if I have brick up
                if (adjacentObject instanceof  Brick){ // can be another fellow enemy tank
                        return 4; // move left only
                }else if (adjacentObject instanceof  EnemyTank){ // can be another fellow enemy tank
                    return 0; // move left only
                }               
            }else if (sth_On_TheLeft){ // checks if I have brick on my left
                if (adjacentObject instanceof  Brick){ // can be another fellow enemy tank
                     System.out.println("S4");
                        return 6; // move left only
                }else if (adjacentObject instanceof  EnemyTank){ // can be another fellow enemy tank
                    return 2; // move left only
                }               
            }
        }
         return -1; // no object on three sides at all, keep moving random
    }
    
    //If playerTank is near, the shooterTank will then detect the presence and start shooting : method returns true
    public boolean playerOnSight(EnemyTank shooterTank){
        double ePosX = shooterTank.getCoordinateX();
        double ePosY = shooterTank.getCoordinateY();
        double pPosX = getPlayerTank().getCoordinateX();
        double pPosY = getPlayerTank().getCoordinateY();
        if(getPlayerTank().isAlive() && shooterTank.isAlive()){
            if(!shooterTank.getFrozenState()){
                if( (ePosX-pPosX) <=100 && (ePosX-pPosX) > 0 && Math.abs(ePosY-pPosY) <=24 ){    
                    return true;
                }
                if( (ePosX-pPosX) >=-100 && (ePosX-pPosX) < 0  && Math.abs(ePosY-pPosY) <= 24){  
                    return true;
                }

                if( (ePosY-pPosY) >=-100 && (ePosY-pPosY) < 0 && Math.abs(ePosX-pPosX)<=24){
                    return true;
                }
                if( (ePosY-pPosY) <=100 && (ePosY-pPosY) > 0 && Math.abs(ePosX-pPosX)<=24){
                    return true;
                }
            }
        }
        return false;  
    }
    
    // if player tank is near , move towards him and shoot
    public void shootIfOnSight(EnemyTank shooterTank){
        double ePosX = shooterTank.getCoordinateX();
        double ePosY = shooterTank.getCoordinateY();
        double pPosX = getPlayerTank().getCoordinateX();
        double pPosY = getPlayerTank().getCoordinateY();
        if(getPlayerTank().isAlive() && shooterTank.isAlive()){
            if(!shooterTank.getFrozenState()){
                if(!getPlayerTank().getFrozenState()){
                    if( (ePosX-pPosX) <=100 && (ePosX-pPosX) > 0 && Math.abs(ePosY-pPosY) <=20 ){              
                        shooterTank.shootMetalOrIce();
                        if((ePosX-pPosX) > 0 && (ePosX-pPosX) < 45  )
                              shooterTank.moveInDirection(2,true); // set him to stop
                        else
                              shooterTank.moveInDirection(2,false); // set him to move left toward player  
                    }
                    if( (ePosX-pPosX) >=-100 && (ePosX-pPosX) < 0  && Math.abs(ePosY-pPosY) <= 20){              
                        shooterTank.shootMetalOrIce();
                        if((ePosX-pPosX) < 0  && (ePosX-pPosX) > -45)
                            shooterTank.moveInDirection(3,true); // set him to stop
                        else
                            shooterTank.moveInDirection(3,false); // set him to move right toward player  
                    }

                    if( (ePosY-pPosY) >=-100 && (ePosY-pPosY) < 0 && Math.abs(ePosX-pPosX)<=20){
                        shooterTank.shootMetalOrIce();
                        if((ePosY-pPosY) < 0 && (ePosY-pPosY) > -45  )  
                            shooterTank.moveInDirection(1,true); // set him to stop
                        else
                            shooterTank.moveInDirection(1,false); // set him to move DOWN toward player                       
                    }
                    if( (ePosY-pPosY) <=100 && (ePosY-pPosY) > 0 && Math.abs(ePosX-pPosX)<=20){
                        shooterTank.shootMetalOrIce();
                        if((ePosY-pPosY) >0 && (ePosY-pPosY) < 45 ){
                           shooterTank.moveInDirection(0,true); // set him to stop                   
                        }
                        else
                            shooterTank.moveInDirection(0,false); // set him to move DOWN toward player  
                    }
                }
            }      
        }             
    }
     
     // assist the bullet animation logic. 
    public void decerementBulletRange() {
        for(int i = 0 ; i < bulletList.size() ; i++){
            bulletList.get(i).decrementBulletRange();
            boolean bulletDeletedOnce = false;
            if(!bulletIsInsideMap(bulletList.get(i))){
                allObjectsList.remove(bulletList.get(i));
                bulletList.get(i).getBulletOwner().setBullet(null);
                bulletList.remove(bulletList.get(i));
                bulletDeletedOnce = true; // skips array index out of bounds, or else attempts to delete same bullet twice 
            }
            else if(bulletList.get(i).getRange() <= 0 && !bulletDeletedOnce){
                allObjectsList.remove(bulletList.get(i));
                bulletList.get(i).getBulletOwner().setBullet(null);
                bulletList.remove(bulletList.get(i));
            }
        }
    }
    
    // Regulates bullet passing thru the status bar. If bullet is shot towards the status bar
    // it will be deleted once it touches the status bar
    public boolean bulletIsInsideMap(Bullet bullet){
        if (bullet.getCoordinateY() >= 590 ){ // 2 = limit movement beyond lower boundary y < 556
            return false;
        }
        return true;
    }

    // Shows the dialog box on game end points : clear level, win game, lose
    private void showDialog( boolean won, int level){
        Alert alert = new Alert(Alert.AlertType.INFORMATION);        
        String levelClearedContent = "You may proceed to next level";        
        String gameClearedHeader = "ALL LEVELS CLEARED! YOU WON ! :D";
        String gameClearedContent = "You are now a licensed TANK driver!!";        
        String gameLostHeader  = "GAME OVER";
        String gameLostContent = "You failed your master shame on you! ";
        alert.setTitle("Information");
        System.out.println("=====>"+ won);
        fileManager = new FileManager(); // this line makes sure the file exists and creates it if not
        if(!won){
            fileManager.writeScore(username, points);
            showTheBoxInformation( alert, "Restart Game", gameLostHeader, gameLostContent,  false,  level);
        }if (won){
            if(level == 2){
                showTheBoxInformation( alert, "Next Level",  "LEVEL " + 1 + " CLEARED" , levelClearedContent,  won,  level);
            }
            else if (level == 3){
                showTheBoxInformation( alert, "Next Level",  "LEVEL " + 2 + " CLEARED", levelClearedContent,  won,  level);
            }
            else{
                showTheBoxInformation( alert, "Restart Game", gameClearedHeader, gameClearedContent,  won,  level); 
                
                fileManager.writeScore(username, points);
            }
        }
    }  
    
    // Constructs the alert dialog box
    public void showTheBoxInformation(Alert alert, String btn, String header, String content, boolean won, int level){
        alert.setHeaderText(header);
        alert.setContentText(content);
        System.out.println("-->" + header );
        System.out.println("-->" + content);
        
        if(btn.equalsIgnoreCase("Next Level")){                  
            alert.setOnHidden(evt -> setAlertOnClickAction(false,false)  ); // start next level);                    
        }
        if(btn.equalsIgnoreCase("Restart Game")){
             alert.setOnHidden(evt -> setAlertOnClickAction(false, true));
        }
        alert.show();
    }
    
    //Decides action that need to be taken when OK is clicked on the Alert Dialog Box
    public void setAlertOnClickAction(boolean  b, boolean exit){
          if(!exit){
            allObjectsList= new ArrayList<>();
            this.initializeLevel1(b);
            timer.start();
          }
          else{
                canvas.getScene().getWindow().hide(); 
                Parent root= null;
                try {
                    root = FXMLLoader.load(Panzer2017.class.getResource("MainMenu.fxml"));
                } catch (IOException ex) {
                    ex.printStackTrace();
                }
                Scene nnew=new Scene(root);                    
                Stage newStage = new Stage();
                newStage.setScene(nnew); 
                newStage.show();
          }
    }
  
    public static void playSound(String soundFileName){
        if (soundOnOrOff){
            MediaPlayer mediaPlayer;
            Media sound = new Media(MainMenuController.class.getResource(soundFileName).toExternalForm());
            mediaPlayer = new MediaPlayer(sound);  
            mediaPlayer.play();
        }
    }
    
    public static void setExit( boolean value){
        exit = value;
    }
}