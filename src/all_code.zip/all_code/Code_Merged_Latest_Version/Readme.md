Merged code of all students goes here
